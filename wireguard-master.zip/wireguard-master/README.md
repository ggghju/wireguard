### 关于


#### _install.sh
> centos版wireguard一键脚本 | centos 7
#### _install_ubuntu.sh
> ubuntu版wireguard一键脚本 | ubuntu >= 14.04
#### _game.sh
> centos版wireguard+udpspeeder+udp2raw一键脚本 | centos 7
#### _game_ubuntu.sh
> ubuntu版wireguard+udpspeeder+udp2raw一键脚本 | ubuntu >= 14.04


